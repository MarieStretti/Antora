(function () {
  'use strict'
  console.log('ONE')
})()
