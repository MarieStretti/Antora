(function () {
  'use strict'
  console.log('TWO')
})()
